# 🏓 Pung Pong

**Retro-inspired chat PWA with ping-pong messaging, self-destructing messages, and MSN vibes.**

All messages auto-delete after 48 hours. No exceptions.

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    GitHub Pages (Static)                  │
│  ┌─────────────────────────────────────────────────────┐ │
│  │  React + Vite PWA (TypeScript, Tailwind)            │ │
│  │  HashRouter · Service Worker · Offline Cache        │ │
│  └───────────────────────┬─────────────────────────────┘ │
└──────────────────────────┼───────────────────────────────┘
                           │ Firebase SDK (modular)
┌──────────────────────────┼───────────────────────────────┐
│                     Firebase Backend                      │
│  ┌───────────┐  ┌────────┴──────┐  ┌──────────────────┐ │
│  │   Auth    │  │  Firestore    │  │  Cloud Storage   │ │
│  │ (Google)  │  │  + TTL Policy │  │  (once-photos)   │ │
│  └───────────┘  └───────────────┘  └──────────────────┘ │
│  ┌───────────────────┐  ┌────────────────────────────┐   │
│  │ Cloud Functions v2 │  │  FCM (Push Notifications) │   │
│  │ (Scheduled cleanup)│  │                            │   │
│  └───────────────────┘  └────────────────────────────┘   │
└──────────────────────────────────────────────────────────┘
```

## Repo Structure

```
pung-pong/
├── web/                          # Vite React PWA
│   ├── src/
│   │   ├── components/           # UI components
│   │   │   ├── Avatar.tsx
│   │   │   ├── StatusBadge.tsx
│   │   │   ├── ContactList.tsx
│   │   │   ├── ChatView.tsx
│   │   │   ├── AddFriendModal.tsx
│   │   │   ├── FriendRequestsModal.tsx
│   │   │   ├── SettingsModal.tsx
│   │   │   └── Toast.tsx
│   │   ├── contexts/             # React contexts
│   │   │   ├── AuthContext.tsx
│   │   │   ├── ThemeContext.tsx
│   │   │   └── SoundContext.tsx
│   │   ├── hooks/                # Custom hooks
│   │   │   ├── useChat.ts
│   │   │   ├── useFriends.ts
│   │   │   └── useNotifications.ts
│   │   ├── lib/                  # Firebase + API
│   │   │   ├── firebase.ts
│   │   │   ├── api.ts
│   │   │   └── cache.ts
│   │   ├── pages/
│   │   │   ├── LoginPage.tsx
│   │   │   ├── OnboardingPage.tsx
│   │   │   └── HomePage.tsx
│   │   ├── types/index.ts
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── index.css
│   ├── public/
│   │   ├── firebase-messaging-sw.js
│   │   └── icons/
│   ├── index.html
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   └── package.json
├── functions/                    # Cloud Functions v2
│   ├── src/index.ts
│   ├── package.json
│   └── tsconfig.json
├── firestore.rules
├── firestore.indexes.json
├── storage.rules
├── firebase.json
├── .github/workflows/deploy.yml
└── README.md
```

## Features

| Feature | Description |
|---------|-------------|
| 🏓 Ping-Pong | Send 1 message → wait for reply → send again |
| ∞ Spam Mode | Both friends enable → unlimited messaging |
| 📸 Once-Photos | View once, tap again to delete (server-side) |
| ⏰ 48h Auto-Delete | All messages vanish after 48 hours everywhere |
| 🔗 Connect Codes | Stable unique code (like a phone number) |
| 👋 Nudge | MSN-style nudge with rate limiting |
| 🎭 Presence | Online/Away/Busy/Invisible + status messages |
| 😊 Emoticons | Classic MSN emoticon shortcuts |
| 🔔 Push Notifications | FCM for messages, requests, nudges |
| 🌙 Dark/Light Mode | Theme toggle with system preference support |
| 🔊 Sounds | Toggleable notification sounds (Web Audio API) |
| 🚫 Block/Remove | Full block + friendship management |

## Setup Guide

### Prerequisites

- Node.js 18+
- Firebase CLI: `npm install -g firebase-tools`
- A Firebase project (Blaze plan for Cloud Functions)
- A GitHub repository

### 1. Firebase Project Setup

```bash
# Login to Firebase
firebase login

# Init project (if starting fresh)
firebase init
```

**Required Firebase services:**
- Authentication (Google provider)
- Cloud Firestore
- Cloud Storage
- Cloud Functions
- Cloud Messaging (FCM)

### 2. Configure Firebase Auth

1. Go to [Firebase Console](https://console.firebase.google.com) → Authentication → Settings
2. Add **Authorized domains**:
   - `your-username.github.io`
   - `localhost` (for development)
3. Enable **Google** sign-in provider

> **GitHub Pages Auth Note:**
> We use `signInWithPopup` because GitHub Pages doesn't easily support redirect callbacks.
> If popup is blocked, the user will see an error. Safari users may need to allow popups.
>
> **Redirect Best Practices (alternative):**
> If using `signInWithRedirect`:
> - Set `authDomain` to your custom domain or `your-username.github.io`
> - Add `/__/auth/handler` route handling
> - Use `getRedirectResult()` on app load
> - See: https://firebase.google.com/docs/auth/web/redirect-best-practices

### 3. Enable Firestore TTL Policy

The TTL policy automatically deletes documents when their `expireAt` field passes.

```bash
# Via gcloud CLI:
gcloud firestore fields ttls update expireAt \
  --collection-group=messages \
  --project=pung-pong

# Or via Firebase Console:
# Firestore → TTL Policies → Create Policy
# Collection group: messages
# Timestamp field: expireAt
```

> **Important:** TTL deletion can be delayed up to 24h after expiry. Our security rules ensure messages are immediately *unreadable* after 48h regardless. The scheduled Cloud Function provides an additional cleanup pass every hour.

### 4. Deploy Firebase Rules & Functions

```bash
# Deploy Firestore rules
firebase deploy --only firestore:rules

# Deploy Firestore indexes
firebase deploy --only firestore:indexes

# Deploy Storage rules
firebase deploy --only storage

# Deploy Cloud Functions
cd functions && npm install && cd ..
firebase deploy --only functions
```

### 5. Deploy Web to GitHub Pages

**Option A: GitHub Actions (recommended)**

1. Push code to `main` branch
2. Go to GitHub repo → Settings → Pages
3. Set source to "GitHub Actions"
4. The workflow in `.github/workflows/deploy.yml` will auto-deploy

**Option B: Manual**

```bash
cd web
npm install
npm run build
# Copy dist/ contents to gh-pages branch
```

### 6. Update `vite.config.ts` Base Path

If your repo is named `pung-pong` and hosted at `username.github.io/pung-pong/`:

```ts
base: "/pung-pong/"
```

For root domain (`username.github.io`):

```ts
base: "/"
```

---

## Data Model

### `users/{uid}`
```json
{
  "displayName": "Alice",
  "code": "ABC12345",
  "photoURL": "https://...",
  "status": "online",
  "statusMessage": "Feeling chatty!",
  "presence": { "lastSeenAt": "Timestamp" },
  "createdAt": "Timestamp"
}
```

### `friendships/{aUid_bUid}`
```json
{
  "aUid": "uid1",
  "bUid": "uid2",
  "createdAt": "Timestamp",
  "spamAEnabled": false,
  "spamBEnabled": false,
  "mutedA": false,
  "mutedB": false
}
```

### `chats/{chatId}`
```json
{
  "members": ["uid1", "uid2"],
  "createdAt": "Timestamp",
  "lastMessagePreview": "Hey!",
  "lastMessageAt": "Timestamp",
  "lastMessageExpireAt": "Timestamp",
  "turnUid": "uid1",
  "spamEnabled": false
}
```

### `chats/{chatId}/messages/{messageId}`
```json
{
  "chatId": "uid1_uid2",
  "senderUid": "uid1",
  "type": "text",
  "text": "Hello!",
  "createdAt": "Timestamp (server)",
  "expireAt": "Timestamp (createdAt + 48h)",
  "state": "sent",
  "viewState": "unopened"
}
```

---

## 48h Auto-Deletion Strategy

### Layer 1: Security Rules (Immediate)
```
allow read: if request.time < resource.data.expireAt
```
Messages become **unreadable** the instant they expire, even before physical deletion.

### Layer 2: Firestore TTL Policy (Automatic)
The `expireAt` field triggers automatic document deletion. Note: TTL deletion can be delayed by up to 24h.

### Layer 3: Scheduled Cloud Function (Hourly)
`cleanupExpiredMessages` runs every 60 minutes:
- Finds all messages where `expireAt <= now`
- Hard-deletes message documents
- Deletes associated Storage files (once-photos)
- Scrubs `lastMessagePreview` in chat documents

### Layer 4: Client Cache Purge
On app start and hourly, the client purges any locally cached expired messages.

### Layer 5: Honest Limitations
- Firebase may retain system-level backups temporarily
- We don't generate additional logs/exports
- App + Firestore + Storage are actively cleaned

---

## Ping-Pong Mechanics

1. Chat starts with `turnUid` set to first user (canonical order)
2. Only `turnUid` can send messages
3. After sending, `turnUid` flips to the other user
4. **Spam Mode:** Both users toggle spam on → `spamEnabled = true` → unlimited messaging

---

## Once-Photo Flow

1. **Client:** Compress image (max 1MB, 1200px)
2. **Client:** Convert to base64, send to `sendOncePhoto` Cloud Function
3. **Server:** Decode base64, save to Storage (`onceMedia/{chatId}/{msgId}.jpg`), create message doc
4. **Recipient opens:** `viewOncePhoto` → sets `viewState="opened"`, returns signed URL (5min)
5. **Recipient taps again:** `deleteOncePhoto` → deletes Storage file + marks message deleted
6. **Race conditions:** Transaction ensures `unopened → opened` transition is atomic

---

## Test Cases

1. ✅ Ping-Pong turn switching: Send message → turnUid flips → sender can't send again
2. ✅ Spam handshake: A enables spam → still ping-pong · B also enables → unlimited
3. ✅ Block prevents: friend requests, messages, message reads
4. ✅ 48h expiry: Security rules deny reads after expireAt
5. ✅ Scheduled cleanup: Hourly function deletes expired messages + storage
6. ✅ Photo open: First tap opens (viewState → opened), gets signed URL
7. ✅ Photo delete: Second tap deletes storage file + marks deleted
8. ✅ Photo race condition: Transaction prevents double-open
9. ✅ Connect code uniqueness: Code generation retries on collision
10. ✅ Friend request auto-accept: Mutual requests = instant friendship
11. ✅ FCM respects mute: Muted friends don't receive push
12. ✅ Nudge rate limit: Max 1 nudge per 30 seconds per chat

---

## Development

```bash
# Start web dev server
cd web && npm install && npm run dev

# Start Firebase emulators (optional)
firebase emulators:start

# Build for production
cd web && npm run build
```

## License

MIT
