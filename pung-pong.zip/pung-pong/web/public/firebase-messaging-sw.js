// Firebase Cloud Messaging service worker
// This runs in the background to handle push notifications

importScripts(
  "https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js"
);
importScripts(
  "https://www.gstatic.com/firebasejs/10.8.0/firebase-messaging-compat.js"
);

firebase.initializeApp({
  apiKey: "AIzaSyCvNwbM1B-ySP6gNWz1A9ESk5IvNQy0wgY",
  authDomain: "pung-pong.firebaseapp.com",
  projectId: "pung-pong",
  storageBucket: "pung-pong.firebasestorage.app",
  messagingSenderId: "742806617606",
  appId: "1:742806617606:web:f1643d069b9e1b4c118d87",
});

const messaging = firebase.messaging();

// Background message handler
messaging.onBackgroundMessage((payload) => {
  const { title, body } = payload.notification || {};
  const options = {
    body: body || "",
    icon: "/icons/icon-192.png",
    badge: "/icons/icon-192.png",
    tag: payload.data?.type || "default",
    data: payload.data,
  };

  self.registration.showNotification(title || "Pung Pong", options);
});

// Notification click handler
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const chatId = event.notification.data?.chatId;

  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes("pung-pong") && "focus" in client) {
          if (chatId) {
            client.postMessage({ type: "NAVIGATE", chatId });
          }
          return client.focus();
        }
      }
      const url = chatId ? `/#/chat/${chatId}` : "/";
      return clients.openWindow(url);
    })
  );
});
