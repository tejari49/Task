import React from "react";
import { HashRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { ThemeProvider } from "./contexts/ThemeContext";
import { SoundProvider } from "./contexts/SoundContext";
import ToastContainer from "./components/Toast";
import LoginPage from "./pages/LoginPage";
import OnboardingPage from "./pages/OnboardingPage";
import HomePage from "./pages/HomePage";

function AppRoutes() {
  const { user, loading, isOnboarded } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-950">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-msn-blue to-msn-purple flex items-center justify-center shadow-xl shadow-msn-blue/20 mx-auto mb-4 animate-pulse">
            <span className="text-3xl">🏓</span>
          </div>
          <div className="w-8 h-8 border-2 border-msn-blue/30 border-t-msn-blue rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  if (!isOnboarded) {
    return <OnboardingPage />;
  }

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/chat/:chatId" element={<HomePage />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <SoundProvider>
          <HashRouter>
            <AppRoutes />
            <ToastContainer />
          </HashRouter>
        </SoundProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
