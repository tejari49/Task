import { httpsCallable } from "firebase/functions";
import { functions } from "./firebase";

// Typed callable wrappers
function callable<TData = unknown, TResult = unknown>(name: string) {
  return httpsCallable<TData, TResult>(functions, name);
}

export const api = {
  setupUser: callable<{ displayName: string }, { code: string }>("setupUser"),
  lookupUserByCode: callable<
    { code: string },
    { uid: string; displayName: string; photoURL: string; status: string }
  >("lookupUserByCode"),
  sendFriendRequest: callable<
    { toUid: string },
    { status: string; friendshipId?: string }
  >("sendFriendRequest"),
  acceptFriendRequest: callable<{ requestId: string }, { status: string }>(
    "acceptFriendRequest"
  ),
  rejectFriendRequest: callable<{ requestId: string }, { status: string }>(
    "rejectFriendRequest"
  ),
  removeFriend: callable<{ friendUid: string }, { status: string }>(
    "removeFriend"
  ),
  blockUser: callable<{ blockedUid: string }, { status: string }>("blockUser"),
  unblockUser: callable<{ blockedUid: string }, { status: string }>(
    "unblockUser"
  ),
  sendMessage: callable<
    { chatId: string; text: string },
    { messageId: string }
  >("sendMessage"),
  sendOncePhoto: callable<
    { chatId: string; base64Data: string },
    { messageId: string }
  >("sendOncePhoto"),
  viewOncePhoto: callable<
    { chatId: string; messageId: string },
    { viewState: string; url: string | null; shouldDelete?: boolean }
  >("viewOncePhoto"),
  deleteOncePhoto: callable<
    { chatId: string; messageId: string },
    { status: string }
  >("deleteOncePhoto"),
  toggleSpam: callable<
    { friendUid: string; enabled: boolean },
    { spamEnabled: boolean }
  >("toggleSpam"),
  sendNudge: callable<{ chatId: string }, { status: string }>("sendNudge"),
  updatePresence: callable<
    { status?: string; statusMessage?: string },
    { status: string }
  >("updatePresence"),
  registerFcmToken: callable<{ token: string }, { status: string }>(
    "registerFcmToken"
  ),
};
