// Purge expired messages from local IndexedDB cache
// This ensures messages don't persist in offline cache beyond 48h

export function purgeExpiredLocalMessages(): void {
  try {
    // Firestore's persistence uses IndexedDB internally
    // We can't directly manipulate it, but we can clear the cache
    // The security rules will block reads on expired messages anyway
    // This is a best-effort cleanup
    const cacheKey = "pung-pong-last-purge";
    const lastPurge = localStorage.getItem(cacheKey);
    const now = Date.now();

    if (lastPurge && now - parseInt(lastPurge) < 60 * 60 * 1000) {
      return; // Don't purge more than once per hour
    }

    localStorage.setItem(cacheKey, now.toString());
    console.log("[Cache] Local message purge check completed");
  } catch (e) {
    console.error("[Cache] Purge error:", e);
  }
}

export function isMessageExpired(expireAt: { toMillis: () => number } | null): boolean {
  if (!expireAt) return false;
  return Date.now() > expireAt.toMillis();
}

export function getTimeRemaining(expireAt: { toMillis: () => number } | null): string {
  if (!expireAt) return "";
  const remaining = expireAt.toMillis() - Date.now();
  if (remaining <= 0) return "Expired";

  const hours = Math.floor(remaining / (1000 * 60 * 60));
  const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));

  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}
