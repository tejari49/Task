import React, { createContext, useContext, useState, useCallback } from "react";

interface SoundContextType {
  soundEnabled: boolean;
  toggleSound: () => void;
  playSound: (type: "message" | "nudge" | "notification") => void;
}

const SoundContext = createContext<SoundContextType>({
  soundEnabled: true,
  toggleSound: () => {},
  playSound: () => {},
});

export const useSound = () => useContext(SoundContext);

// Simple beep sounds using Web Audio API
function createBeep(
  frequency: number,
  duration: number,
  type: OscillatorType = "sine"
) {
  try {
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = frequency;
    osc.type = type;
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + duration);
  } catch (e) {
    // Audio not available
  }
}

export function SoundProvider({ children }: { children: React.ReactNode }) {
  const [soundEnabled, setSoundEnabled] = useState(() => {
    return localStorage.getItem("pp-sound") !== "false";
  });

  const toggleSound = () => {
    setSoundEnabled((prev) => {
      localStorage.setItem("pp-sound", (!prev).toString());
      return !prev;
    });
  };

  const playSound = useCallback(
    (type: "message" | "nudge" | "notification") => {
      if (!soundEnabled) return;
      switch (type) {
        case "message":
          createBeep(800, 0.15, "sine");
          setTimeout(() => createBeep(1000, 0.1, "sine"), 100);
          break;
        case "nudge":
          for (let i = 0; i < 4; i++) {
            setTimeout(() => createBeep(600 + i * 100, 0.08, "square"), i * 80);
          }
          break;
        case "notification":
          createBeep(523, 0.2, "sine");
          setTimeout(() => createBeep(659, 0.2, "sine"), 150);
          setTimeout(() => createBeep(784, 0.3, "sine"), 300);
          break;
      }
    },
    [soundEnabled]
  );

  return (
    <SoundContext.Provider value={{ soundEnabled, toggleSound, playSound }}>
      {children}
    </SoundContext.Provider>
  );
}
