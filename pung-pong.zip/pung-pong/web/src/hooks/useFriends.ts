import { useEffect, useState } from "react";
import {
  collection,
  query,
  where,
  onSnapshot,
  doc,
  getDoc,
} from "firebase/firestore";
import { db } from "../lib/firebase";
import { useAuth } from "../contexts/AuthContext";
import {
  Friendship,
  FriendRequest,
  UserProfile,
  FriendWithProfile,
  Chat,
} from "../types";

export function useFriends() {
  const { user } = useAuth();
  const [friends, setFriends] = useState<FriendWithProfile[]>([]);
  const [requests, setRequests] = useState<
    (FriendRequest & { fromProfile?: UserProfile })[]
  >([]);
  const [loading, setLoading] = useState(true);

  // Listen to friendships
  useEffect(() => {
    if (!user) return;
    const uid = user.uid;

    // Query where user is aUid
    const q1 = query(collection(db, "friendships"), where("aUid", "==", uid));
    const q2 = query(collection(db, "friendships"), where("bUid", "==", uid));

    let friendsA: Friendship[] = [];
    let friendsB: Friendship[] = [];

    const unsub1 = onSnapshot(q1, (snap) => {
      friendsA = snap.docs.map(
        (d) => ({ id: d.id, ...d.data() } as Friendship)
      );
      mergeAndEnrich();
    });

    const unsub2 = onSnapshot(q2, (snap) => {
      friendsB = snap.docs.map(
        (d) => ({ id: d.id, ...d.data() } as Friendship)
      );
      mergeAndEnrich();
    });

    async function mergeAndEnrich() {
      const all = [...friendsA, ...friendsB];
      const enriched: FriendWithProfile[] = [];

      for (const f of all) {
        const friendUid = f.aUid === uid ? f.bUid : f.aUid;
        try {
          const profileSnap = await getDoc(doc(db, "users", friendUid));
          const chatSnap = await getDoc(doc(db, "chats", f.id));

          if (profileSnap.exists()) {
            enriched.push({
              ...f,
              friendProfile: {
                uid: profileSnap.id,
                ...profileSnap.data(),
              } as UserProfile,
              chat: chatSnap.exists()
                ? ({ id: chatSnap.id, ...chatSnap.data() } as Chat)
                : undefined,
            });
          }
        } catch (e) {
          console.error("Error enriching friend:", e);
        }
      }

      // Sort: online first, then by last message
      enriched.sort((a, b) => {
        const statusOrder = { online: 0, away: 1, busy: 2, invisible: 3 };
        const aOrder = statusOrder[a.friendProfile.status] ?? 3;
        const bOrder = statusOrder[b.friendProfile.status] ?? 3;
        if (aOrder !== bOrder) return aOrder - bOrder;

        const aTime = a.chat?.lastMessageAt?.toMillis() ?? 0;
        const bTime = b.chat?.lastMessageAt?.toMillis() ?? 0;
        return bTime - aTime;
      });

      setFriends(enriched);
      setLoading(false);
    }

    return () => {
      unsub1();
      unsub2();
    };
  }, [user]);

  // Listen to friend requests
  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, "friendRequests"),
      where("toUid", "==", user.uid)
    );

    const unsub = onSnapshot(q, async (snap) => {
      const reqs: (FriendRequest & { fromProfile?: UserProfile })[] = [];
      for (const d of snap.docs) {
        const req = { id: d.id, ...d.data() } as FriendRequest;
        try {
          const profileSnap = await getDoc(doc(db, "users", req.fromUid));
          if (profileSnap.exists()) {
            reqs.push({
              ...req,
              fromProfile: {
                uid: profileSnap.id,
                ...profileSnap.data(),
              } as UserProfile,
            });
          } else {
            reqs.push(req);
          }
        } catch {
          reqs.push(req);
        }
      }
      setRequests(reqs);
    });

    return () => unsub();
  }, [user]);

  return { friends, requests, loading };
}
