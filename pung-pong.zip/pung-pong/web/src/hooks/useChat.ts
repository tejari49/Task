import { useEffect, useState, useCallback } from "react";
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  doc,
  where,
  Timestamp,
  limit,
} from "firebase/firestore";
import { db } from "../lib/firebase";
import { useAuth } from "../contexts/AuthContext";
import { Message, Chat } from "../types";
import { isMessageExpired } from "../lib/cache";

export function useChat(chatId: string | undefined) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [chat, setChat] = useState<Chat | null>(null);
  const [loading, setLoading] = useState(true);

  // Listen to chat document
  useEffect(() => {
    if (!chatId || !user) return;

    const unsub = onSnapshot(
      doc(db, "chats", chatId),
      (snap) => {
        if (snap.exists()) {
          setChat({ id: snap.id, ...snap.data() } as Chat);
        }
      },
      (err) => console.error("Chat listener error:", err)
    );

    return () => unsub();
  }, [chatId, user]);

  // Listen to messages (only non-expired)
  useEffect(() => {
    if (!chatId || !user) return;

    const now = Timestamp.now();
    const messagesRef = collection(db, "chats", chatId, "messages");

    // Query messages where expireAt > now (not yet expired)
    const q = query(
      messagesRef,
      where("expireAt", ">", now),
      orderBy("expireAt", "asc"),
      limit(200)
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const msgs: Message[] = [];
        snap.docs.forEach((d) => {
          const msg = { id: d.id, ...d.data() } as Message;
          // Double-check on client side
          if (!isMessageExpired(msg.expireAt)) {
            msgs.push(msg);
          }
        });
        // Sort by createdAt
        msgs.sort((a, b) => {
          const aTime = a.createdAt?.toMillis?.() ?? 0;
          const bTime = b.createdAt?.toMillis?.() ?? 0;
          return aTime - bTime;
        });
        setMessages(msgs);
        setLoading(false);
      },
      (err) => {
        console.error("Messages listener error:", err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, [chatId, user]);

  // Check if it's current user's turn
  const isMyTurn = chat?.turnUid === user?.uid;
  const canSend = chat?.spamEnabled || isMyTurn;

  return { messages, chat, loading, isMyTurn, canSend };
}
