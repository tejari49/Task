import { useEffect } from "react";
import { getToken, onMessage } from "firebase/messaging";
import { getMessagingInstance, VAPID_KEY } from "../lib/firebase";
import { api } from "../lib/api";
import { useAuth } from "../contexts/AuthContext";
import { useSound } from "../contexts/SoundContext";

export function useNotifications() {
  const { user } = useAuth();
  const { playSound } = useSound();

  useEffect(() => {
    if (!user) return;

    async function setup() {
      try {
        const messaging = await getMessagingInstance();
        if (!messaging) return;

        const permission = await Notification.requestPermission();
        if (permission !== "granted") return;

        const token = await getToken(messaging, { vapidKey: VAPID_KEY });
        if (token) {
          await api.registerFcmToken({ token });
        }

        // Foreground messages
        onMessage(messaging, (payload) => {
          const { title, body } = payload.notification || {};
          const type = payload.data?.type;

          if (type === "nudge") {
            playSound("nudge");
          } else {
            playSound("notification");
          }

          // Show in-app notification if page is visible
          if (document.visibilityState === "visible") {
            // Could show a toast here
            console.log("Foreground message:", title, body);
          }
        });
      } catch (e) {
        console.error("FCM setup error:", e);
      }
    }

    setup();
  }, [user, playSound]);
}
