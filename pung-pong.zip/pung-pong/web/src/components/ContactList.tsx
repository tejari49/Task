import React from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useFriends } from "../hooks/useFriends";
import Avatar from "./Avatar";
import { StatusLabel } from "./StatusBadge";
import { formatDistanceToNow } from "date-fns";
import { FriendWithProfile } from "../types";

interface Props {
  activeChatId?: string;
  onOpenAddFriend: () => void;
  onOpenRequests: () => void;
  onOpenSettings: () => void;
}

export default function ContactList({
  activeChatId,
  onOpenAddFriend,
  onOpenRequests,
  onOpenSettings,
}: Props) {
  const navigate = useNavigate();
  const { profile, signOut } = useAuth();
  const { friends, requests } = useFriends();

  const onlineFriends = friends.filter(
    (f) => f.friendProfile.status === "online"
  );
  const otherFriends = friends.filter(
    (f) => f.friendProfile.status !== "online"
  );

  return (
    <div className="flex flex-col h-full">
      {/* Header / User Info */}
      <div className="p-4 border-b border-white/5">
        <div className="flex items-center gap-3 mb-3">
          <Avatar
            src={profile?.photoURL}
            name={profile?.displayName || "You"}
            size="lg"
            status={profile?.status}
          />
          <div className="flex-1 min-w-0">
            <h2 className="font-display font-bold text-base truncate">
              {profile?.displayName}
            </h2>
            <p className="text-xs text-surface-300 font-mono truncate">
              {profile?.code}
            </p>
            {profile?.statusMessage && (
              <p className="text-xs text-surface-300 truncate italic mt-0.5">
                "{profile.statusMessage}"
              </p>
            )}
          </div>
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-lg hover:bg-white/5 transition-colors"
            title="Settings"
          >
            <svg className="w-5 h-5 text-surface-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </button>
        </div>

        {/* Action buttons */}
        <div className="flex gap-2">
          <button
            onClick={onOpenAddFriend}
            className="flex-1 btn-primary text-xs py-2"
          >
            + Add Friend
          </button>
          <button
            onClick={onOpenRequests}
            className="relative btn-secondary text-xs py-2 px-3"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-5-5m0 0l5-5M15 12H3" />
            </svg>
            {requests.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-msn-red rounded-full text-[10px] font-bold flex items-center justify-center animate-bounce-in">
                {requests.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Contact List */}
      <div className="flex-1 overflow-y-auto">
        {friends.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full p-6 text-center">
            <span className="text-4xl mb-3">🏓</span>
            <p className="text-surface-300 text-sm">No friends yet</p>
            <p className="text-surface-300/60 text-xs mt-1">
              Add friends with their connect code
            </p>
          </div>
        ) : (
          <>
            {/* Online section */}
            {onlineFriends.length > 0 && (
              <div>
                <div className="px-4 py-2 text-xs font-semibold text-msn-green uppercase tracking-wider">
                  Online ({onlineFriends.length})
                </div>
                {onlineFriends.map((f) => (
                  <FriendRow
                    key={f.id}
                    friend={f}
                    isActive={activeChatId === f.id}
                    onClick={() => navigate(`/chat/${f.id}`)}
                  />
                ))}
              </div>
            )}

            {/* Other section */}
            {otherFriends.length > 0 && (
              <div>
                <div className="px-4 py-2 text-xs font-semibold text-surface-300/60 uppercase tracking-wider">
                  {onlineFriends.length > 0 ? "Others" : "Friends"} ({otherFriends.length})
                </div>
                {otherFriends.map((f) => (
                  <FriendRow
                    key={f.id}
                    friend={f}
                    isActive={activeChatId === f.id}
                    onClick={() => navigate(`/chat/${f.id}`)}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function FriendRow({
  friend,
  isActive,
  onClick,
}: {
  friend: FriendWithProfile;
  isActive: boolean;
  onClick: () => void;
}) {
  const { friendProfile, chat } = friend;
  const lastSeen = friendProfile.presence?.lastSeenAt;

  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 transition-all duration-150 text-left hover:bg-white/5 ${
        isActive ? "bg-msn-blue/10 border-l-2 border-msn-blue" : ""
      }`}
    >
      <Avatar
        src={friendProfile.photoURL}
        name={friendProfile.displayName}
        status={friendProfile.status}
      />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <span className="font-medium text-sm truncate">
            {friendProfile.displayName}
          </span>
          {chat?.lastMessageAt && (
            <span className="text-[10px] text-surface-300/60 shrink-0">
              {formatDistanceToNow(chat.lastMessageAt.toDate(), {
                addSuffix: false,
              })}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1.5">
          {friendProfile.statusMessage ? (
            <p className="text-xs text-surface-300 truncate italic">
              {friendProfile.statusMessage}
            </p>
          ) : chat?.lastMessagePreview ? (
            <p className="text-xs text-surface-300/60 truncate">
              {chat.lastMessagePreview}
            </p>
          ) : (
            <StatusLabel status={friendProfile.status} />
          )}
        </div>
      </div>

      {/* Turn indicator */}
      {chat && !chat.spamEnabled && (
        <div className="shrink-0" title={chat.turnUid === friend.aUid ? "Their turn" : "Your turn"}>
          <span className="text-lg">
            {chat.turnUid !== friend.friendProfile.uid ? "🟢" : ""}
          </span>
        </div>
      )}
    </button>
  );
}
