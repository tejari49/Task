import React, { useState } from "react";
import { useFriends } from "../hooks/useFriends";
import { api } from "../lib/api";
import { showToast } from "./Toast";
import Avatar from "./Avatar";

interface Props {
  onClose: () => void;
}

export default function FriendRequestsModal({ onClose }: Props) {
  const { requests } = useFriends();
  const [processing, setProcessing] = useState<string | null>(null);

  const handleAccept = async (requestId: string) => {
    setProcessing(requestId);
    try {
      await api.acceptFriendRequest({ requestId });
      showToast("Friend added! 🎉", "success");
    } catch (err: any) {
      showToast(err.message || "Failed to accept", "error");
    } finally {
      setProcessing(null);
    }
  };

  const handleReject = async (requestId: string) => {
    setProcessing(requestId);
    try {
      await api.rejectFriendRequest({ requestId });
      showToast("Request declined", "info");
    } catch (err: any) {
      showToast(err.message || "Failed to decline", "error");
    } finally {
      setProcessing(null);
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="glass-panel w-full max-w-sm p-6 bg-surface-900 animate-slide-up max-h-[80vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-xl font-bold">Friend Requests</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/5">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3">
          {requests.length === 0 ? (
            <div className="text-center py-8">
              <span className="text-3xl mb-2 block">📭</span>
              <p className="text-surface-300 text-sm">No pending requests</p>
            </div>
          ) : (
            requests.map((req) => (
              <div key={req.id} className="glass-card animate-fade-in">
                <div className="flex items-center gap-3 mb-3">
                  <Avatar
                    src={req.fromProfile?.photoURL}
                    name={req.fromProfile?.displayName || "Unknown"}
                    showStatus={false}
                  />
                  <div className="flex-1">
                    <p className="font-semibold text-sm">
                      {req.fromProfile?.displayName || "Unknown user"}
                    </p>
                    <p className="text-xs text-surface-300">
                      wants to connect
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleAccept(req.id)}
                    disabled={processing === req.id}
                    className="flex-1 btn-primary text-xs py-2 disabled:opacity-50"
                  >
                    Accept
                  </button>
                  <button
                    onClick={() => handleReject(req.id)}
                    disabled={processing === req.id}
                    className="flex-1 btn-secondary text-xs py-2 disabled:opacity-50 text-msn-red"
                  >
                    Decline
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
