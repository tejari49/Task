import React, { useState, useRef, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useSound } from "../contexts/SoundContext";
import { useChat } from "../hooks/useChat";
import { useFriends } from "../hooks/useFriends";
import { api } from "../lib/api";
import { getTimeRemaining } from "../lib/cache";
import { showToast } from "./Toast";
import Avatar from "./Avatar";
import { StatusLabel } from "./StatusBadge";
import { EMOTICONS, Message } from "../types";
import imageCompression from "browser-image-compression";
import { formatDistanceToNow } from "date-fns";

export default function ChatView() {
  const { chatId } = useParams<{ chatId: string }>();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { playSound } = useSound();
  const { messages, chat, loading, canSend, isMyTurn } = useChat(chatId);
  const { friends } = useFriends();

  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [showEmoticons, setShowEmoticons] = useState(false);
  const [nudging, setNudging] = useState(false);
  const [viewingPhoto, setViewingPhoto] = useState<{
    url: string;
    messageId: string;
  } | null>(null);
  const [photoLoading, setPhotoLoading] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const friend = friends.find((f) => f.id === chatId);
  const friendProfile = friend?.friendProfile;

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  // Play sound on new message from other
  const prevMsgCount = useRef(messages.length);
  useEffect(() => {
    if (messages.length > prevMsgCount.current) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg?.senderUid !== user?.uid) {
        playSound("message");
      }
    }
    prevMsgCount.current = messages.length;
  }, [messages.length, user?.uid, playSound]);

  // Nudge detection
  useEffect(() => {
    if (
      chat?.lastNudgeBy &&
      chat.lastNudgeBy !== user?.uid &&
      chat.lastNudgeAt
    ) {
      const nudgeTime = chat.lastNudgeAt.toMillis();
      if (Date.now() - nudgeTime < 5000) {
        setNudging(true);
        playSound("nudge");
        setTimeout(() => setNudging(false), 500);
      }
    }
  }, [chat?.lastNudgeAt, chat?.lastNudgeBy, user?.uid, playSound]);

  // Replace emoticon shortcuts
  const processEmoticons = (input: string): string => {
    let result = input;
    for (const [code, emoji] of Object.entries(EMOTICONS)) {
      result = result.replaceAll(code, emoji);
    }
    return result;
  };

  // Send text message
  const handleSend = async () => {
    if (!text.trim() || !chatId || sending) return;

    const processed = processEmoticons(text.trim());
    setSending(true);
    setText("");

    try {
      await api.sendMessage({ chatId, text: processed });
    } catch (err: any) {
      showToast(
        err.message || "Failed to send message",
        "error"
      );
      setText(processed);
    } finally {
      setSending(false);
      inputRef.current?.focus();
    }
  };

  // Send photo
  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !chatId) return;

    setPhotoLoading(true);
    try {
      // Compress image
      const compressed = await imageCompression(file, {
        maxSizeMB: 1,
        maxWidthOrHeight: 1200,
        useWebWorker: true,
      });

      // Convert to base64
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = (reader.result as string).split(",")[1];
        try {
          await api.sendOncePhoto({ chatId, base64Data: base64 });
          showToast("Photo sent!", "success");
        } catch (err: any) {
          showToast(err.message || "Failed to send photo", "error");
        } finally {
          setPhotoLoading(false);
        }
      };
      reader.readAsDataURL(compressed);
    } catch (err: any) {
      showToast("Failed to compress image", "error");
      setPhotoLoading(false);
    }

    // Reset file input
    e.target.value = "";
  };

  // View once-photo
  const handleViewPhoto = async (msg: Message) => {
    if (!chatId || msg.viewState === "deleted") return;

    try {
      const result = await api.viewOncePhoto({
        chatId,
        messageId: msg.id,
      });

      if (result.data.url) {
        setViewingPhoto({ url: result.data.url, messageId: msg.id });
      } else if (result.data.shouldDelete) {
        // Second tap — delete
        await api.deleteOncePhoto({ chatId, messageId: msg.id });
        showToast("Photo deleted", "info");
      }
    } catch (err: any) {
      showToast(err.message || "Cannot view photo", "error");
    }
  };

  // Close photo viewer and delete
  const handleClosePhoto = async () => {
    if (viewingPhoto && chatId) {
      try {
        await api.deleteOncePhoto({
          chatId,
          messageId: viewingPhoto.messageId,
        });
      } catch {
        // Ignore errors
      }
    }
    setViewingPhoto(null);
  };

  // Send nudge
  const handleNudge = async () => {
    if (!chatId) return;
    try {
      await api.sendNudge({ chatId });
      showToast("Nudge sent! 👋", "info");
    } catch (err: any) {
      showToast(err.message || "Can't nudge right now", "error");
    }
  };

  // Key handler
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!chatId) {
    return (
      <div className="flex-1 flex items-center justify-center text-surface-300">
        <div className="text-center">
          <span className="text-6xl mb-4 block">🏓</span>
          <p className="font-display text-xl font-bold">Select a chat</p>
          <p className="text-sm text-surface-300/60 mt-1">
            Choose a friend to start chatting
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-msn-blue/30 border-t-msn-blue rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div
      className={`flex flex-col h-full ${nudging ? "nudge-shake" : ""}`}
      ref={chatContainerRef}
    >
      {/* Chat Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-white/5 shrink-0">
        {/* Back button on mobile */}
        <button
          onClick={() => navigate("/")}
          className="md:hidden p-1.5 rounded-lg hover:bg-white/5"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        {friendProfile && (
          <>
            <Avatar
              src={friendProfile.photoURL}
              name={friendProfile.displayName}
              status={friendProfile.status}
            />
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-sm truncate">
                {friendProfile.displayName}
              </h3>
              <div className="flex items-center gap-2">
                <StatusLabel status={friendProfile.status} />
                {friendProfile.presence?.lastSeenAt &&
                  friendProfile.status !== "online" && (
                    <span className="text-[10px] text-surface-300/40">
                      {formatDistanceToNow(
                        friendProfile.presence.lastSeenAt.toDate(),
                        { addSuffix: true }
                      )}
                    </span>
                  )}
              </div>
            </div>
          </>
        )}

        {/* Nudge & Spam info */}
        <div className="flex items-center gap-2">
          {chat?.spamEnabled && (
            <span
              className="text-xs bg-msn-purple/20 text-msn-purple px-2 py-1 rounded-full font-medium"
              title="Spam mode active — unlimited messages"
            >
              ∞ SPAM
            </span>
          )}
          <button
            onClick={handleNudge}
            className="p-2 rounded-lg hover:bg-white/5 transition-colors"
            title="Nudge"
          >
            <span className="text-xl">👋</span>
          </button>
        </div>
      </div>

      {/* Turn indicator bar */}
      {chat && !chat.spamEnabled && (
        <div
          className={`px-4 py-1.5 text-xs text-center font-medium transition-colors ${
            isMyTurn
              ? "bg-msn-green/10 text-msn-green"
              : "bg-msn-orange/10 text-msn-orange"
          }`}
        >
          {isMyTurn
            ? "🏓 Your turn! Send a message"
            : `⏳ Waiting for ${friendProfile?.displayName || "their"} reply...`}
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <span className="text-4xl mb-2">🏓</span>
            <p className="text-surface-300 text-sm">No messages yet</p>
            <p className="text-surface-300/40 text-xs">
              Start the conversation!
            </p>
          </div>
        )}

        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            message={msg}
            isMine={msg.senderUid === user?.uid}
            onViewPhoto={() => handleViewPhoto(msg)}
          />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="px-4 py-3 border-t border-white/5 shrink-0 safe-bottom">
        <div className="flex items-center gap-2">
          {/* Photo button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={!canSend || photoLoading}
            className="p-2.5 rounded-lg hover:bg-white/5 transition-colors disabled:opacity-30"
            title="Send once-photo"
          >
            {photoLoading ? (
              <div className="w-5 h-5 border-2 border-msn-purple/30 border-t-msn-purple rounded-full animate-spin" />
            ) : (
              <svg className="w-5 h-5 text-msn-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            )}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handlePhotoSelect}
            className="hidden"
          />

          {/* Emoticons toggle */}
          <button
            onClick={() => setShowEmoticons(!showEmoticons)}
            className="p-2.5 rounded-lg hover:bg-white/5 transition-colors"
            title="Emoticons"
          >
            <span className="text-lg">😊</span>
          </button>

          {/* Text input */}
          <div className="flex-1 relative">
            <input
              ref={inputRef}
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={!canSend}
              placeholder={
                canSend ? "Type a message..." : "Wait for their reply..."
              }
              className="input-field pr-10 text-white placeholder:text-surface-300/40 disabled:opacity-40"
              maxLength={2000}
            />
          </div>

          {/* Send button */}
          <button
            onClick={handleSend}
            disabled={!text.trim() || !canSend || sending}
            className="btn-primary px-4 py-2.5 disabled:opacity-30 disabled:cursor-not-allowed"
          >
            {sending ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            )}
          </button>
        </div>

        {/* Emoticons panel */}
        {showEmoticons && (
          <div className="mt-2 glass-panel p-3 grid grid-cols-8 gap-1 animate-slide-up">
            {Object.entries(EMOTICONS).map(([code, emoji]) => (
              <button
                key={code}
                onClick={() => {
                  setText((prev) => prev + emoji);
                  inputRef.current?.focus();
                }}
                className="p-2 rounded-lg hover:bg-white/10 transition-colors text-lg"
                title={code}
              >
                {emoji}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Photo viewer overlay */}
      {viewingPhoto && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={handleClosePhoto}
        >
          <div className="text-center">
            <p className="text-white/60 text-sm mb-4">
              Tap anywhere to close & delete
            </p>
            <img
              src={viewingPhoto.url}
              alt="Once photo"
              className="max-w-full max-h-[70vh] rounded-xl shadow-2xl"
            />
            <p className="text-white/40 text-xs mt-4">
              This photo will be deleted when you close it
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Message Bubble ─────────────────────────────────────────────

function MessageBubble({
  message,
  isMine,
  onViewPhoto,
}: {
  message: Message;
  isMine: boolean;
  onViewPhoto: () => void;
}) {
  const timeRemaining = getTimeRemaining(message.expireAt);

  if (message.type === "photo_once") {
    return (
      <div className={`flex ${isMine ? "justify-end" : "justify-start"}`}>
        <button
          onClick={onViewPhoto}
          className="photo-once-bubble px-5 py-4 text-white max-w-[70%]"
          disabled={message.viewState === "deleted"}
        >
          {message.viewState === "deleted" ? (
            <div className="flex items-center gap-2 text-white/60">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
              </svg>
              <span className="text-sm">Photo deleted</span>
            </div>
          ) : message.viewState === "opened" ? (
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              <span className="text-sm">Tap to delete</span>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <div className="photo-shimmer w-6 h-6 rounded-full" />
              <span className="text-sm font-medium">📷 View photo</span>
            </div>
          )}
        </button>
      </div>
    );
  }

  return (
    <div
      className={`flex ${isMine ? "justify-end" : "justify-start"} animate-fade-in`}
    >
      <div className="group">
        <div className={`chat-bubble ${isMine ? "sent" : "received"}`}>
          {message.text}
        </div>
        <div
          className={`flex items-center gap-2 mt-0.5 px-1 ${
            isMine ? "justify-end" : "justify-start"
          }`}
        >
          <span className="text-[10px] text-surface-300/30">
            {message.createdAt?.toDate
              ? new Date(message.createdAt.toDate()).toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                })
              : ""}
          </span>
          <span className="text-[10px] text-surface-300/20 opacity-0 group-hover:opacity-100 transition-opacity">
            {timeRemaining}
          </span>
        </div>
      </div>
    </div>
  );
}
