import React from "react";
import { StatusType } from "../types";

interface Props {
  status: StatusType;
  size?: "sm" | "md" | "lg";
  className?: string;
}

export default function StatusBadge({ status, size = "md", className = "" }: Props) {
  const sizeClasses = {
    sm: "w-2 h-2",
    md: "w-2.5 h-2.5",
    lg: "w-3 h-3",
  };

  return (
    <span
      className={`status-dot ${status} ${sizeClasses[size]} ${className}`}
      title={status.charAt(0).toUpperCase() + status.slice(1)}
    />
  );
}

export function StatusLabel({ status }: { status: StatusType }) {
  const labels: Record<StatusType, string> = {
    online: "Online",
    away: "Away",
    busy: "Busy",
    invisible: "Invisible",
  };
  const colors: Record<StatusType, string> = {
    online: "text-msn-green",
    away: "text-msn-orange",
    busy: "text-msn-red",
    invisible: "text-surface-300",
  };

  return (
    <span className={`text-xs font-medium ${colors[status]}`}>
      {labels[status]}
    </span>
  );
}
