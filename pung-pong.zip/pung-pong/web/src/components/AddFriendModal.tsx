import React, { useState } from "react";
import { api } from "../lib/api";
import { showToast } from "./Toast";
import Avatar from "./Avatar";

interface Props {
  onClose: () => void;
}

export default function AddFriendModal({ onClose }: Props) {
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [foundUser, setFoundUser] = useState<{
    uid: string;
    displayName: string;
    photoURL: string;
    status: string;
  } | null>(null);
  const [sending, setSending] = useState(false);

  const handleLookup = async () => {
    if (!code.trim()) return;
    setLoading(true);
    setFoundUser(null);

    try {
      const result = await api.lookupUserByCode({ code: code.trim() });
      setFoundUser(result.data);
    } catch (err: any) {
      showToast(err.message || "User not found", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleSendRequest = async () => {
    if (!foundUser) return;
    setSending(true);

    try {
      const result = await api.sendFriendRequest({ toUid: foundUser.uid });
      if (result.data.status === "accepted") {
        showToast("You're now friends! 🎉", "success");
      } else {
        showToast("Friend request sent!", "success");
      }
      onClose();
    } catch (err: any) {
      showToast(err.message || "Failed to send request", "error");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="glass-panel w-full max-w-sm p-6 bg-surface-900 animate-slide-up" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-xl font-bold">Add Friend</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/5">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm text-surface-300 mb-2">
              Enter Connect Code
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="e.g. ABC12345"
                className="input-field flex-1 font-mono text-white uppercase tracking-widest placeholder:text-surface-300/30 placeholder:tracking-normal placeholder:normal-case"
                maxLength={8}
                onKeyDown={(e) => e.key === "Enter" && handleLookup()}
              />
              <button
                onClick={handleLookup}
                disabled={!code.trim() || loading}
                className="btn-primary disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  "Find"
                )}
              </button>
            </div>
          </div>

          {foundUser && (
            <div className="glass-card animate-fade-in">
              <div className="flex items-center gap-3 mb-4">
                <Avatar
                  src={foundUser.photoURL}
                  name={foundUser.displayName}
                  size="lg"
                  showStatus={false}
                />
                <div>
                  <p className="font-semibold">{foundUser.displayName}</p>
                  <p className="text-xs text-surface-300 capitalize">
                    {foundUser.status}
                  </p>
                </div>
              </div>
              <button
                onClick={handleSendRequest}
                disabled={sending}
                className="btn-primary w-full disabled:opacity-50"
              >
                {sending ? "Sending..." : "Send Friend Request"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
