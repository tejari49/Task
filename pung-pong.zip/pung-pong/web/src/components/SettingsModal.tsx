import React, { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useTheme } from "../contexts/ThemeContext";
import { useSound } from "../contexts/SoundContext";
import { api } from "../lib/api";
import { showToast } from "./Toast";
import Avatar from "./Avatar";
import { StatusType } from "../types";

interface Props {
  onClose: () => void;
}

export default function SettingsModal({ onClose }: Props) {
  const { profile, signOut } = useAuth();
  const { theme, toggle: toggleTheme } = useTheme();
  const { soundEnabled, toggleSound } = useSound();

  const [displayName, setDisplayName] = useState(profile?.displayName || "");
  const [statusMessage, setStatusMessage] = useState(
    profile?.statusMessage || ""
  );
  const [status, setStatus] = useState<StatusType>(profile?.status || "online");
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      if (displayName.trim() !== profile?.displayName) {
        await api.setupUser({ displayName: displayName.trim() });
      }
      await api.updatePresence({ status, statusMessage });
      showToast("Settings saved!", "success");
      onClose();
    } catch (err: any) {
      showToast(err.message || "Failed to save", "error");
    } finally {
      setSaving(false);
    }
  };

  const handleCopyCode = () => {
    if (profile?.code) {
      navigator.clipboard.writeText(profile.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const statuses: { value: StatusType; label: string; color: string }[] = [
    { value: "online", label: "Online", color: "bg-msn-green" },
    { value: "away", label: "Away", color: "bg-msn-orange" },
    { value: "busy", label: "Busy", color: "bg-msn-red" },
    { value: "invisible", label: "Invisible", color: "bg-surface-300" },
  ];

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div
        className="glass-panel w-full max-w-md p-6 bg-surface-900 animate-slide-up max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-xl font-bold">Settings</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/5">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="space-y-6">
          {/* Profile */}
          <div>
            <h3 className="text-sm font-semibold text-surface-300 uppercase tracking-wider mb-3">
              Profile
            </h3>
            <div className="flex items-center gap-4 mb-4">
              <Avatar
                src={profile?.photoURL}
                name={profile?.displayName || ""}
                size="lg"
                status={status}
              />
              <div className="flex-1">
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="input-field text-white mb-2"
                  placeholder="Display name"
                  maxLength={30}
                />
                <input
                  type="text"
                  value={statusMessage}
                  onChange={(e) => setStatusMessage(e.target.value)}
                  className="input-field text-white text-xs"
                  placeholder="Status message (optional)"
                  maxLength={100}
                />
              </div>
            </div>
          </div>

          {/* Connect Code */}
          <div>
            <h3 className="text-sm font-semibold text-surface-300 uppercase tracking-wider mb-3">
              Connect Code
            </h3>
            <div className="flex items-center gap-2">
              <code className="flex-1 text-center py-3 rounded-lg bg-white/5 font-mono text-lg tracking-[0.3em] font-bold text-msn-blue">
                {profile?.code}
              </code>
              <button
                onClick={handleCopyCode}
                className="btn-secondary px-4 py-3"
              >
                {copied ? "✓" : "Copy"}
              </button>
            </div>
            <p className="text-xs text-surface-300/50 mt-2 text-center">
              Share this code with friends so they can find you
            </p>
          </div>

          {/* Status */}
          <div>
            <h3 className="text-sm font-semibold text-surface-300 uppercase tracking-wider mb-3">
              Status
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {statuses.map((s) => (
                <button
                  key={s.value}
                  onClick={() => setStatus(s.value)}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border transition-all ${
                    status === s.value
                      ? "border-msn-blue bg-msn-blue/10"
                      : "border-white/5 hover:bg-white/5"
                  }`}
                >
                  <span className={`w-2.5 h-2.5 rounded-full ${s.color}`} />
                  <span className="text-sm">{s.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Toggles */}
          <div>
            <h3 className="text-sm font-semibold text-surface-300 uppercase tracking-wider mb-3">
              Preferences
            </h3>
            <div className="space-y-3">
              <ToggleRow
                label="Dark Mode"
                icon="🌙"
                enabled={theme === "dark"}
                onToggle={toggleTheme}
              />
              <ToggleRow
                label="Sounds"
                icon="🔊"
                enabled={soundEnabled}
                onToggle={toggleSound}
              />
            </div>
          </div>

          {/* Save + Sign Out */}
          <div className="space-y-3 pt-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="btn-primary w-full disabled:opacity-50"
            >
              {saving ? "Saving..." : "Save Changes"}
            </button>
            <button
              onClick={() => {
                signOut();
                onClose();
              }}
              className="w-full py-2.5 rounded-lg text-sm font-medium text-msn-red hover:bg-msn-red/10 transition-colors"
            >
              Sign Out
            </button>
          </div>

          {/* Privacy notice */}
          <div className="text-center text-[10px] text-surface-300/30 leading-relaxed">
            All messages auto-delete after 48 hours.
            <br />
            Firebase TTL + scheduled cleanup ensures complete removal.
            <br />
            Provider backups may retain data temporarily.
          </div>
        </div>
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  icon,
  enabled,
  onToggle,
}: {
  label: string;
  icon: string;
  enabled: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-white/5 transition-colors"
    >
      <div className="flex items-center gap-2">
        <span>{icon}</span>
        <span className="text-sm">{label}</span>
      </div>
      <div
        className={`w-10 h-6 rounded-full p-0.5 transition-colors ${
          enabled ? "bg-msn-blue" : "bg-surface-300/30"
        }`}
      >
        <div
          className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
            enabled ? "translate-x-4" : "translate-x-0"
          }`}
        />
      </div>
    </button>
  );
}
