import React from "react";
import StatusBadge from "./StatusBadge";
import { StatusType } from "../types";

interface Props {
  src?: string;
  name: string;
  size?: "sm" | "md" | "lg";
  status?: StatusType;
  showStatus?: boolean;
}

export default function Avatar({
  src,
  name,
  size = "md",
  status,
  showStatus = true,
}: Props) {
  const sizeClasses = {
    sm: "w-8 h-8 text-xs",
    md: "w-10 h-10 text-sm",
    lg: "w-14 h-14 text-lg",
  };

  const statusPosition = {
    sm: "-bottom-0.5 -right-0.5",
    md: "-bottom-0.5 -right-0.5",
    lg: "bottom-0 right-0",
  };

  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .substring(0, 2)
    .toUpperCase();

  const colors = [
    "from-msn-blue to-msn-purple",
    "from-msn-green to-msn-teal",
    "from-msn-orange to-msn-red",
    "from-msn-purple to-msn-blue",
    "from-msn-teal to-msn-green",
  ];
  const colorIndex =
    name.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0) %
    colors.length;

  return (
    <div className="relative inline-flex shrink-0">
      {src ? (
        <img
          src={src}
          alt={name}
          className={`${sizeClasses[size]} rounded-full object-cover`}
          referrerPolicy="no-referrer"
        />
      ) : (
        <div
          className={`${sizeClasses[size]} rounded-full bg-gradient-to-br ${colors[colorIndex]} flex items-center justify-center font-display font-bold text-white`}
        >
          {initials}
        </div>
      )}
      {showStatus && status && (
        <StatusBadge
          status={status}
          size={size === "lg" ? "md" : "sm"}
          className={`absolute ${statusPosition[size]}`}
        />
      )}
    </div>
  );
}
