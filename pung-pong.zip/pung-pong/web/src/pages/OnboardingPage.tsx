import React, { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { api } from "../lib/api";

export default function OnboardingPage() {
  const { user } = useAuth();
  const [displayName, setDisplayName] = useState(user?.displayName || "");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim() || displayName.trim().length < 2) {
      setError("Name must be at least 2 characters");
      return;
    }

    setLoading(true);
    setError("");
    try {
      const result = await api.setupUser({ displayName: displayName.trim() });
      // Profile listener in AuthContext will pick up the change
      console.log("User setup complete, code:", result.data.code);
    } catch (err: any) {
      setError(err.message || "Setup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-surface-950 via-surface-900 to-msn-teal/10" />

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-8 animate-fade-in">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-msn-teal to-msn-blue shadow-xl mb-4">
            <span className="text-3xl">✨</span>
          </div>
          <h1 className="font-display text-3xl font-bold mb-2">Welcome!</h1>
          <p className="text-surface-300">
            Choose your display name to get started
          </p>
        </div>

        <form onSubmit={handleSubmit} className="glass-panel p-6 space-y-5">
          <div>
            <label className="block text-sm font-medium text-surface-300 mb-2">
              Display Name
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Enter your name..."
              className="input-field text-white placeholder:text-surface-300/50"
              maxLength={30}
              autoFocus
            />
          </div>

          {error && (
            <p className="text-msn-red text-sm animate-fade-in">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading || !displayName.trim()}
            className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Setting up...
              </span>
            ) : (
              "Get my Connect Code →"
            )}
          </button>

          <p className="text-center text-surface-300/60 text-xs">
            You'll get a unique code to share with friends
          </p>
        </form>
      </div>
    </div>
  );
}
