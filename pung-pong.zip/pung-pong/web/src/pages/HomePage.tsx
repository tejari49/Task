import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useNotifications } from "../hooks/useNotifications";
import { purgeExpiredLocalMessages } from "../lib/cache";
import ContactList from "../components/ContactList";
import ChatView from "../components/ChatView";
import AddFriendModal from "../components/AddFriendModal";
import FriendRequestsModal from "../components/FriendRequestsModal";
import SettingsModal from "../components/SettingsModal";

export default function HomePage() {
  const { chatId } = useParams<{ chatId: string }>();
  const { profile } = useAuth();
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [showRequests, setShowRequests] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Setup notifications
  useNotifications();

  // Purge expired local messages on mount + periodic
  useEffect(() => {
    purgeExpiredLocalMessages();
    const interval = setInterval(purgeExpiredLocalMessages, 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  // Update presence on mount
  useEffect(() => {
    if (profile) {
      import("../lib/api").then(({ api }) => {
        api.updatePresence({ status: "online" });
      });

      // Set away/offline on visibility change
      const handleVisibility = () => {
        import("../lib/api").then(({ api }) => {
          api.updatePresence({
            status: document.hidden ? "away" : "online",
          });
        });
      };

      document.addEventListener("visibilitychange", handleVisibility);
      return () => {
        document.removeEventListener("visibilitychange", handleVisibility);
      };
    }
  }, [profile]);

  const showSidebar = !chatId;

  return (
    <div className="h-screen flex overflow-hidden bg-surface-950 safe-top">
      {/* Sidebar / Contact List */}
      <div
        className={`${
          showSidebar ? "flex" : "hidden"
        } md:flex flex-col w-full md:w-80 lg:w-96 border-r border-white/5 bg-surface-950 shrink-0`}
      >
        <ContactList
          activeChatId={chatId}
          onOpenAddFriend={() => setShowAddFriend(true)}
          onOpenRequests={() => setShowRequests(true)}
          onOpenSettings={() => setShowSettings(true)}
        />
      </div>

      {/* Chat Area */}
      <div
        className={`${
          chatId ? "flex" : "hidden"
        } md:flex flex-col flex-1 min-w-0`}
      >
        <ChatView />
      </div>

      {/* Modals */}
      {showAddFriend && (
        <AddFriendModal onClose={() => setShowAddFriend(false)} />
      )}
      {showRequests && (
        <FriendRequestsModal onClose={() => setShowRequests(false)} />
      )}
      {showSettings && (
        <SettingsModal onClose={() => setShowSettings(false)} />
      )}
    </div>
  );
}
