import * as admin from "firebase-admin";
import {
  onCall,
  HttpsError,
  CallableRequest,
} from "firebase-functions/v2/https";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { onDocumentCreated } from "firebase-functions/v2/firestore";

admin.initializeApp();
const db = admin.firestore();
const storage = admin.storage();
const messaging = admin.messaging();

// ─── Helpers ─────────────────────────────────────────────────────

function generateConnectCode(): string {
  // Generate 8-char alphanumeric code (like a phone number)
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

function canonicalFriendshipId(a: string, b: string): string {
  return a < b ? `${a}_${b}` : `${b}_${a}`;
}

async function isBlocked(uid1: string, uid2: string): Promise<boolean> {
  const blocks = await db
    .collection("blocks")
    .where("blockerUid", "in", [uid1, uid2])
    .get();
  return blocks.docs.some(
    (doc) =>
      (doc.data().blockerUid === uid1 && doc.data().blockedUid === uid2) ||
      (doc.data().blockerUid === uid2 && doc.data().blockedUid === uid1)
  );
}

async function sendPushToUser(
  uid: string,
  title: string,
  body: string,
  data?: Record<string, string>
): Promise<void> {
  const tokensSnap = await db
    .collection("fcmTokens")
    .where("uid", "==", uid)
    .get();
  const tokens = tokensSnap.docs.map((d) => d.data().token as string);
  if (tokens.length === 0) return;

  const message: admin.messaging.MulticastMessage = {
    tokens,
    notification: { title, body },
    data: data || {},
    webpush: {
      fcmOptions: { link: "/" },
    },
  };

  try {
    const result = await messaging.sendEachForMulticast(message);
    // Clean up invalid tokens
    result.responses.forEach((resp, idx) => {
      if (!resp.success) {
        const code = resp.error?.code;
        if (
          code === "messaging/invalid-registration-token" ||
          code === "messaging/registration-token-not-registered"
        ) {
          db.collection("fcmTokens")
            .where("token", "==", tokens[idx])
            .get()
            .then((snap) => snap.docs.forEach((d) => d.ref.delete()));
        }
      }
    });
  } catch (e) {
    console.error("Push send error:", e);
  }
}

// ─── User Onboarding ─────────────────────────────────────────────

export const setupUser = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const uid = request.auth.uid;
    const { displayName } = request.data as { displayName: string };

    if (!displayName || displayName.trim().length < 2) {
      throw new HttpsError("invalid-argument", "Display name must be at least 2 chars");
    }

    const userRef = db.collection("users").doc(uid);
    const userSnap = await userRef.get();

    if (userSnap.exists && userSnap.data()?.code) {
      // Update display name only
      await userRef.update({ displayName: displayName.trim() });
      return { code: userSnap.data()?.code };
    }

    // Generate unique code
    let code = "";
    let attempts = 0;
    while (attempts < 20) {
      code = generateConnectCode();
      const existing = await db
        .collection("users")
        .where("code", "==", code)
        .limit(1)
        .get();
      if (existing.empty) break;
      attempts++;
    }
    if (attempts >= 20) {
      throw new HttpsError("internal", "Could not generate unique code");
    }

    await userRef.set(
      {
        displayName: displayName.trim(),
        code,
        photoURL: request.auth.token.picture || "",
        status: "online",
        statusMessage: "",
        presence: { lastSeenAt: admin.firestore.FieldValue.serverTimestamp() },
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    return { code };
  }
);

// ─── Lookup User by Code ─────────────────────────────────────────

export const lookupUserByCode = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { code } = request.data as { code: string };
    if (!code) throw new HttpsError("invalid-argument", "Code required");

    const snap = await db
      .collection("users")
      .where("code", "==", code.toUpperCase().trim())
      .limit(1)
      .get();

    if (snap.empty) {
      throw new HttpsError("not-found", "No user found with this code");
    }

    const userData = snap.docs[0].data();
    const uid = snap.docs[0].id;

    if (uid === request.auth.uid) {
      throw new HttpsError("invalid-argument", "Cannot add yourself");
    }

    // Check if blocked
    if (await isBlocked(request.auth.uid, uid)) {
      throw new HttpsError("permission-denied", "Cannot connect with this user");
    }

    return {
      uid,
      displayName: userData.displayName,
      photoURL: userData.photoURL,
      status: userData.status,
    };
  }
);

// ─── Send Friend Request ─────────────────────────────────────────

export const sendFriendRequest = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { toUid } = request.data as { toUid: string };
    const fromUid = request.auth.uid;

    if (fromUid === toUid)
      throw new HttpsError("invalid-argument", "Cannot add yourself");

    if (await isBlocked(fromUid, toUid)) {
      throw new HttpsError("permission-denied", "Cannot send request");
    }

    // Check existing friendship
    const fId = canonicalFriendshipId(fromUid, toUid);
    const existing = await db.collection("friendships").doc(fId).get();
    if (existing.exists) {
      throw new HttpsError("already-exists", "Already friends");
    }

    // Check existing request
    const existingReq = await db
      .collection("friendRequests")
      .where("fromUid", "==", fromUid)
      .where("toUid", "==", toUid)
      .limit(1)
      .get();
    if (!existingReq.empty) {
      throw new HttpsError("already-exists", "Request already sent");
    }

    // Check reverse request (auto-accept)
    const reverseReq = await db
      .collection("friendRequests")
      .where("fromUid", "==", toUid)
      .where("toUid", "==", fromUid)
      .limit(1)
      .get();

    if (!reverseReq.empty) {
      // Auto-accept: they already sent us a request
      await reverseReq.docs[0].ref.delete();
      await createFriendship(fromUid, toUid);
      return { status: "accepted", friendshipId: fId };
    }

    await db.collection("friendRequests").add({
      fromUid,
      toUid,
      status: "pending",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Push notification
    const senderSnap = await db.collection("users").doc(fromUid).get();
    const senderName = senderSnap.data()?.displayName || "Someone";
    await sendPushToUser(
      toUid,
      "New Friend Request",
      `${senderName} wants to connect with you!`,
      { type: "friendRequest", fromUid }
    );

    return { status: "pending" };
  }
);

// ─── Accept Friend Request ───────────────────────────────────────

export const acceptFriendRequest = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { requestId } = request.data as { requestId: string };
    const reqRef = db.collection("friendRequests").doc(requestId);
    const reqSnap = await reqRef.get();

    if (!reqSnap.exists) throw new HttpsError("not-found", "Request not found");

    const reqData = reqSnap.data()!;
    if (reqData.toUid !== request.auth.uid) {
      throw new HttpsError("permission-denied", "Not your request");
    }

    const { fromUid, toUid } = reqData;
    await createFriendship(fromUid, toUid);
    await reqRef.delete();

    return { status: "accepted" };
  }
);

async function createFriendship(uid1: string, uid2: string): Promise<void> {
  const [aUid, bUid] = uid1 < uid2 ? [uid1, uid2] : [uid2, uid1];
  const fId = `${aUid}_${bUid}`;
  const chatId = fId;

  const batch = db.batch();

  batch.set(db.collection("friendships").doc(fId), {
    aUid,
    bUid,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    spamAEnabled: false,
    spamBEnabled: false,
    mutedA: false,
    mutedB: false,
  });

  batch.set(db.collection("chats").doc(chatId), {
    members: [aUid, bUid],
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    lastMessagePreview: null,
    lastMessageAt: null,
    turnUid: aUid, // First user in canonical order starts
    spamEnabled: false,
  });

  await batch.commit();
}

// ─── Reject Friend Request ───────────────────────────────────────

export const rejectFriendRequest = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");
    const { requestId } = request.data as { requestId: string };
    const reqRef = db.collection("friendRequests").doc(requestId);
    const reqSnap = await reqRef.get();

    if (!reqSnap.exists) throw new HttpsError("not-found", "Request not found");
    if (reqSnap.data()!.toUid !== request.auth.uid) {
      throw new HttpsError("permission-denied", "Not your request");
    }

    await reqRef.delete();
    return { status: "rejected" };
  }
);

// ─── Remove Friend ───────────────────────────────────────────────

export const removeFriend = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { friendUid } = request.data as { friendUid: string };
    const uid = request.auth.uid;
    const fId = canonicalFriendshipId(uid, friendUid);

    const fSnap = await db.collection("friendships").doc(fId).get();
    if (!fSnap.exists) throw new HttpsError("not-found", "Not friends");

    await db.collection("friendships").doc(fId).delete();
    return { status: "removed" };
  }
);

// ─── Block User ──────────────────────────────────────────────────

export const blockUser = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { blockedUid } = request.data as { blockedUid: string };
    const uid = request.auth.uid;
    const blockId = `${uid}_${blockedUid}`;

    const batch = db.batch();

    batch.set(db.collection("blocks").doc(blockId), {
      blockerUid: uid,
      blockedUid,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Also remove friendship if exists
    const fId = canonicalFriendshipId(uid, blockedUid);
    const fSnap = await db.collection("friendships").doc(fId).get();
    if (fSnap.exists) {
      batch.delete(db.collection("friendships").doc(fId));
    }

    // Remove pending requests
    const reqs1 = await db
      .collection("friendRequests")
      .where("fromUid", "==", uid)
      .where("toUid", "==", blockedUid)
      .get();
    const reqs2 = await db
      .collection("friendRequests")
      .where("fromUid", "==", blockedUid)
      .where("toUid", "==", uid)
      .get();
    [...reqs1.docs, ...reqs2.docs].forEach((d) => batch.delete(d.ref));

    await batch.commit();
    return { status: "blocked" };
  }
);

// ─── Unblock User ────────────────────────────────────────────────

export const unblockUser = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { blockedUid } = request.data as { blockedUid: string };
    const blockId = `${request.auth.uid}_${blockedUid}`;
    await db.collection("blocks").doc(blockId).delete();
    return { status: "unblocked" };
  }
);

// ─── Send Text Message ───────────────────────────────────────────

export const sendMessage = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { chatId, text } = request.data as { chatId: string; text: string };
    const senderUid = request.auth.uid;

    if (!text || text.trim().length === 0) {
      throw new HttpsError("invalid-argument", "Message cannot be empty");
    }

    const chatRef = db.collection("chats").doc(chatId);
    const chatSnap = await chatRef.get();

    if (!chatSnap.exists) throw new HttpsError("not-found", "Chat not found");
    const chatData = chatSnap.data()!;

    if (!chatData.members.includes(senderUid)) {
      throw new HttpsError("permission-denied", "Not a member");
    }

    const otherUid = chatData.members.find((m: string) => m !== senderUid);

    // Check block
    if (await isBlocked(senderUid, otherUid)) {
      throw new HttpsError("permission-denied", "Blocked");
    }

    // Check friendship
    const fId = canonicalFriendshipId(senderUid, otherUid);
    const fSnap = await db.collection("friendships").doc(fId).get();
    if (!fSnap.exists) {
      throw new HttpsError("permission-denied", "Not friends");
    }
    const fData = fSnap.data()!;

    // Ping-Pong check
    const spamEnabled = fData.spamAEnabled && fData.spamBEnabled;
    if (!spamEnabled && chatData.turnUid !== senderUid) {
      throw new HttpsError(
        "failed-precondition",
        "Not your turn. Wait for a reply."
      );
    }

    const now = admin.firestore.Timestamp.now();
    const expireAt = admin.firestore.Timestamp.fromMillis(
      now.toMillis() + 48 * 60 * 60 * 1000
    );

    const msgRef = chatRef.collection("messages").doc();

    const batch = db.batch();
    batch.set(msgRef, {
      chatId,
      senderUid,
      type: "text",
      text: text.trim(),
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      expireAt,
      state: "sent",
    });

    // Update turn (ping-pong)
    if (!spamEnabled) {
      batch.update(chatRef, {
        turnUid: otherUid,
        lastMessagePreview: text.trim().substring(0, 50),
        lastMessageAt: admin.firestore.FieldValue.serverTimestamp(),
        lastMessageExpireAt: expireAt,
      });
    } else {
      batch.update(chatRef, {
        lastMessagePreview: text.trim().substring(0, 50),
        lastMessageAt: admin.firestore.FieldValue.serverTimestamp(),
        lastMessageExpireAt: expireAt,
      });
    }

    await batch.commit();

    // Push notification (respect mute)
    const isMuted =
      (fData.aUid === otherUid && fData.mutedA) ||
      (fData.bUid === otherUid && fData.mutedB);

    if (!isMuted) {
      const senderSnap = await db.collection("users").doc(senderUid).get();
      const senderName = senderSnap.data()?.displayName || "Someone";
      await sendPushToUser(otherUid, senderName, text.trim().substring(0, 100), {
        type: "message",
        chatId,
      });
    }

    return { messageId: msgRef.id };
  }
);

// ─── Send Once Photo ─────────────────────────────────────────────

export const sendOncePhoto = onCall(
  { region: "europe-west1", maxInstances: 10 },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { chatId, base64Data } = request.data as {
      chatId: string;
      base64Data: string;
    };
    const senderUid = request.auth.uid;

    if (!base64Data) throw new HttpsError("invalid-argument", "No image data");

    const chatRef = db.collection("chats").doc(chatId);
    const chatSnap = await chatRef.get();
    if (!chatSnap.exists) throw new HttpsError("not-found", "Chat not found");

    const chatData = chatSnap.data()!;
    if (!chatData.members.includes(senderUid)) {
      throw new HttpsError("permission-denied", "Not a member");
    }

    const otherUid = chatData.members.find((m: string) => m !== senderUid);
    if (await isBlocked(senderUid, otherUid)) {
      throw new HttpsError("permission-denied", "Blocked");
    }

    // Ping-Pong check
    const fId = canonicalFriendshipId(senderUid, otherUid);
    const fSnap = await db.collection("friendships").doc(fId).get();
    if (!fSnap.exists) throw new HttpsError("permission-denied", "Not friends");
    const fData = fSnap.data()!;
    const spamEnabled = fData.spamAEnabled && fData.spamBEnabled;
    if (!spamEnabled && chatData.turnUid !== senderUid) {
      throw new HttpsError("failed-precondition", "Not your turn");
    }

    // Decode and upload
    const buffer = Buffer.from(base64Data, "base64");
    if (buffer.length > 5 * 1024 * 1024) {
      throw new HttpsError("invalid-argument", "Image too large (max 5MB)");
    }

    const msgRef = chatRef.collection("messages").doc();
    const storagePath = `onceMedia/${chatId}/${msgRef.id}.jpg`;
    const bucket = storage.bucket();
    const file = bucket.file(storagePath);

    await file.save(buffer, {
      metadata: { contentType: "image/jpeg" },
    });

    const now = admin.firestore.Timestamp.now();
    const expireAt = admin.firestore.Timestamp.fromMillis(
      now.toMillis() + 48 * 60 * 60 * 1000
    );

    const batch = db.batch();
    batch.set(msgRef, {
      chatId,
      senderUid,
      type: "photo_once",
      mediaRef: storagePath,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      expireAt,
      state: "sent",
      viewState: "unopened",
    });

    if (!spamEnabled) {
      batch.update(chatRef, {
        turnUid: otherUid,
        lastMessagePreview: "📷 Photo",
        lastMessageAt: admin.firestore.FieldValue.serverTimestamp(),
        lastMessageExpireAt: expireAt,
      });
    } else {
      batch.update(chatRef, {
        lastMessagePreview: "📷 Photo",
        lastMessageAt: admin.firestore.FieldValue.serverTimestamp(),
        lastMessageExpireAt: expireAt,
      });
    }

    await batch.commit();

    // Push
    const isMuted =
      (fData.aUid === otherUid && fData.mutedA) ||
      (fData.bUid === otherUid && fData.mutedB);
    if (!isMuted) {
      const senderSnap = await db.collection("users").doc(senderUid).get();
      const senderName = senderSnap.data()?.displayName || "Someone";
      await sendPushToUser(otherUid, senderName, "Sent you a photo 📷", {
        type: "photo",
        chatId,
      });
    }

    return { messageId: msgRef.id };
  }
);

// ─── View Once Photo ─────────────────────────────────────────────

export const viewOncePhoto = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { chatId, messageId } = request.data as {
      chatId: string;
      messageId: string;
    };

    const msgRef = db
      .collection("chats")
      .doc(chatId)
      .collection("messages")
      .doc(messageId);

    // Use transaction for race condition safety
    const result = await db.runTransaction(async (tx) => {
      const msgSnap = await tx.get(msgRef);
      if (!msgSnap.exists) throw new HttpsError("not-found", "Message not found");

      const msgData = msgSnap.data()!;
      if (msgData.type !== "photo_once") {
        throw new HttpsError("invalid-argument", "Not a photo message");
      }

      if (msgData.viewState === "deleted") {
        return { viewState: "deleted", url: null };
      }

      if (msgData.viewState === "unopened") {
        tx.update(msgRef, {
          viewState: "opened",
          openedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        // Generate signed URL
        const file = storage.bucket().file(msgData.mediaRef);
        const [url] = await file.getSignedUrl({
          action: "read",
          expires: Date.now() + 5 * 60 * 1000, // 5 min
        });
        return { viewState: "opened", url };
      }

      // Already opened = second tap = delete
      return { viewState: "opened", url: null, shouldDelete: true };
    });

    return result;
  }
);

// ─── Delete Once Photo ───────────────────────────────────────────

export const deleteOncePhoto = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { chatId, messageId } = request.data as {
      chatId: string;
      messageId: string;
    };

    const msgRef = db
      .collection("chats")
      .doc(chatId)
      .collection("messages")
      .doc(messageId);
    const msgSnap = await msgRef.get();

    if (!msgSnap.exists) return { status: "already_deleted" };

    const msgData = msgSnap.data()!;
    if (msgData.mediaRef) {
      try {
        await storage.bucket().file(msgData.mediaRef).delete();
      } catch (e) {
        // File may already be deleted
      }
    }

    await msgRef.update({
      viewState: "deleted",
      mediaRef: admin.firestore.FieldValue.delete(),
      deletedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return { status: "deleted" };
  }
);

// ─── Toggle Spam Mode ────────────────────────────────────────────

export const toggleSpam = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { friendUid, enabled } = request.data as {
      friendUid: string;
      enabled: boolean;
    };
    const uid = request.auth.uid;
    const fId = canonicalFriendshipId(uid, friendUid);

    const fRef = db.collection("friendships").doc(fId);
    const fSnap = await fRef.get();
    if (!fSnap.exists) throw new HttpsError("not-found", "Not friends");

    const fData = fSnap.data()!;
    const isA = fData.aUid === uid;

    const updateData: Record<string, any> = {};
    if (isA) {
      updateData.spamAEnabled = enabled;
    } else {
      updateData.spamBEnabled = enabled;
    }

    await fRef.update(updateData);

    // Update chat spam status
    const updatedSnap = await fRef.get();
    const updatedData = updatedSnap.data()!;
    const chatId = fId;
    const spamEnabled = updatedData.spamAEnabled && updatedData.spamBEnabled;
    await db.collection("chats").doc(chatId).update({ spamEnabled });

    return { spamEnabled };
  }
);

// ─── Nudge ───────────────────────────────────────────────────────

export const sendNudge = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { chatId } = request.data as { chatId: string };
    const senderUid = request.auth.uid;

    const chatSnap = await db.collection("chats").doc(chatId).get();
    if (!chatSnap.exists) throw new HttpsError("not-found", "Chat not found");

    const chatData = chatSnap.data()!;
    if (!chatData.members.includes(senderUid)) {
      throw new HttpsError("permission-denied", "Not a member");
    }

    // Rate limit: 1 nudge per 30 seconds per chat
    const lastNudge = chatData.lastNudgeAt?.toMillis() || 0;
    if (Date.now() - lastNudge < 30000) {
      throw new HttpsError("resource-exhausted", "Wait before nudging again");
    }

    await db.collection("chats").doc(chatId).update({
      lastNudgeAt: admin.firestore.FieldValue.serverTimestamp(),
      lastNudgeBy: senderUid,
    });

    const otherUid = chatData.members.find((m: string) => m !== senderUid);
    const senderSnap = await db.collection("users").doc(senderUid).get();
    const senderName = senderSnap.data()?.displayName || "Someone";

    await sendPushToUser(otherUid, `${senderName} nudged you! 👋`, "Hey! Are you there?", {
      type: "nudge",
      chatId,
    });

    return { status: "sent" };
  }
);

// ─── Update Presence ─────────────────────────────────────────────

export const updatePresence = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { status, statusMessage } = request.data as {
      status?: string;
      statusMessage?: string;
    };

    const updateData: Record<string, any> = {
      "presence.lastSeenAt": admin.firestore.FieldValue.serverTimestamp(),
    };
    if (status) updateData.status = status;
    if (statusMessage !== undefined) updateData.statusMessage = statusMessage;

    await db.collection("users").doc(request.auth.uid).update(updateData);
    return { status: "ok" };
  }
);

// ─── Register FCM Token ──────────────────────────────────────────

export const registerFcmToken = onCall(
  { region: "europe-west1" },
  async (request: CallableRequest) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required");

    const { token } = request.data as { token: string };
    if (!token) throw new HttpsError("invalid-argument", "Token required");

    // Use token as doc ID to prevent duplicates
    await db.collection("fcmTokens").doc(token).set({
      uid: request.auth.uid,
      token,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return { status: "registered" };
  }
);

// ─── Scheduled Cleanup (48h TTL) ─────────────────────────────────

export const cleanupExpiredMessages = onSchedule(
  {
    schedule: "every 60 minutes",
    region: "europe-west1",
    timeoutSeconds: 540,
  },
  async () => {
    const now = admin.firestore.Timestamp.now();
    const batchSize = 100;

    // Find expired messages across all chats (collection group query)
    let query = db
      .collectionGroup("messages")
      .where("expireAt", "<=", now)
      .limit(batchSize);

    let totalDeleted = 0;

    while (true) {
      const snap = await query.get();
      if (snap.empty) break;

      const batch = db.batch();
      const mediaToDelete: string[] = [];

      for (const doc of snap.docs) {
        const data = doc.data();
        if (data.mediaRef) {
          mediaToDelete.push(data.mediaRef);
        }
        batch.delete(doc.ref);
      }

      await batch.commit();
      totalDeleted += snap.docs.length;

      // Delete associated storage files
      for (const path of mediaToDelete) {
        try {
          await storage.bucket().file(path).delete();
        } catch (e) {
          // Already deleted
        }
      }

      if (snap.docs.length < batchSize) break;

      // Continue from last doc
      query = db
        .collectionGroup("messages")
        .where("expireAt", "<=", now)
        .startAfter(snap.docs[snap.docs.length - 1])
        .limit(batchSize);
    }

    // Scrub lastMessagePreview for chats whose last message expired
    const chatsSnap = await db
      .collection("chats")
      .where("lastMessageExpireAt", "<=", now)
      .get();

    if (!chatsSnap.empty) {
      const batch = db.batch();
      for (const doc of chatsSnap.docs) {
        batch.update(doc.ref, {
          lastMessagePreview: "Messages expired",
          lastMessageExpireAt: admin.firestore.FieldValue.delete(),
        });
      }
      await batch.commit();
    }

    console.log(`Cleanup: deleted ${totalDeleted} expired messages`);
  }
);
